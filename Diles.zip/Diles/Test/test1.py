from PIL import Image
import pytesseract

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# Path to your image
img = Image.open("Test/test2.jpg")

# Run OCR
text = pytesseract.image_to_string(img)
print(text)
