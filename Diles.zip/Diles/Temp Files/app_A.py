# Desktop App
import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from Dile_Scanner import build_word_map_with_cache
from Dile_Finder import load_word_map, search_phrase

PATH_FILE = "path.txt"

def save_path(path):
    with open(PATH_FILE, "w") as f:
        f.write(path)

def load_path():
    return open(PATH_FILE).read().strip() if os.path.exists(PATH_FILE) else ""

def choose_folder():
    selected = filedialog.askdirectory()
    if selected:
        folder_var.set(selected)
        save_path(selected)

def run_indexing():
    folder = folder_var.get()
    if not folder or not os.path.isdir(folder):
        messagebox.showwarning("Invalid Folder", "Please select a valid folder.")
        return

    progress.start()
    index_button.config(state=tk.DISABLED)

    def background():
        updated = build_word_map_with_cache(folder)
        app.after(0, lambda: on_index_done(updated))

    threading.Thread(target=background, daemon=True).start()

def on_index_done(updated):
    progress.stop()
    index_button.config(state=tk.NORMAL)
    msg = "Word map updated." if updated else "No changes detected. Using cached index."
    messagebox.showinfo("Indexing", msg)

def perform_search():
    phrase = search_entry.get().strip()
    result_list.delete(0, tk.END)
    if not phrase:
        return

    try:
        word_map = load_word_map()
        matches = search_phrase(word_map, phrase)
        if matches:
            for m in matches:
                result_list.insert(tk.END, m)
        else:
            result_list.insert(tk.END, "No matches found.")
    except FileNotFoundError:
        messagebox.showerror("Missing File", "word_map.txt not found. Please create index first.")


# === GUI Setup ===
app = tk.Tk()
app.title("PDF Index & Search Tool")
app.geometry("700x500")
app.configure(bg="#f0f4f8")

folder_var = tk.StringVar(value=load_path())

# Folder Selection
tk.Label(app, text="Selected Folder:", bg="#f0f4f8").pack(pady=(10, 0))
tk.Entry(app, textvariable=folder_var, width=60, state="readonly").pack(pady=5)
tk.Button(app, text="Choose Folder", command=choose_folder, bg="#1a73e8", fg="white").pack()

# Index Creator
index_button = tk.Button(app, text="Create Index", command=run_indexing, bg="#34a853", fg="white")
index_button.pack(pady=10)

progress = ttk.Progressbar(app, mode='indeterminate', length=400)
progress.pack(pady=5)

# Search Bar
tk.Label(app, text="Search Phrase:", bg="#f0f4f8").pack(pady=(15, 0))
search_entry = tk.Entry(app, width=50)
search_entry.pack(pady=5)
tk.Button(app, text="Search", command=perform_search, bg="#fbbc05", fg="black").pack()

# Search Result
result_list = tk.Listbox(app, font=("Consolas", 11))
result_list.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

app.mainloop()