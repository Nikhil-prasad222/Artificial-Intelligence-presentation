import re
import json
from collections import defaultdict

def load_word_map(file_path="word_map.json"):
    with open(file_path, 'r', encoding='utf-8') as f:
        raw_map = json.load(f)

    # Convert into: token -> set of "filename (Page X)" strings
    word_map = {}
    for token, file_pages in raw_map.items():
        locations = []
        for file, pages in file_pages.items():
            for page in pages:
                locations.append(f"Page {page} - {file}")
        word_map[token] = locations
    return word_map

def tokenize_search_input(text):
    return re.findall(r'\b\w+\b|[^\s\w]', text.lower())

def search_phrase(word_map, phrase):
    tokens = tokenize_search_input(phrase)
    pdf_sets = []

    for token in tokens:
        if token in word_map:
            pdf_sets.append(set(word_map[token]))
        else:
            return []  # If any token is missing, phrase can't match

    return sorted(set.intersection(*pdf_sets)) if pdf_sets else []