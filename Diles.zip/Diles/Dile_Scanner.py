import os
import re
import json
from collections import defaultdict
from PyPDF2 import PdfReader
from concurrent.futures import ProcessPoolExecutor, as_completed

CACHE_FILE = "scan_cache.json"
OUTPUT_JSON = "word_map.json"

def extract_tokens_from_pdf(pdf_path):
    token_map = defaultdict(set)
    try:
        reader = PdfReader(pdf_path)
        filename = os.path.basename(pdf_path)
        for page_number, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ''
            tokens = re.findall(r'\b\w+\b|[^\s\w]', text.lower())
            for token in tokens:
                token_map[token].add((filename, page_number))
        return token_map
    except Exception as e:
        print(f"Error processing {pdf_path}: {e}")
        return defaultdict(set)

def merge_token_maps(all_maps):
    merged = defaultdict(set)
    for token_map in all_maps:
        for token, locations in token_map.items():
            merged[token].update(locations)
    return merged

def load_existing_word_map_json():
    word_map = defaultdict(set)
    if not os.path.exists(OUTPUT_JSON):
        return word_map

    with open(OUTPUT_JSON, 'r', encoding='utf-8') as f:
        data = json.load(f)
        for token, file_pages in data.items():
            for file, pages in file_pages.items():
                for page in pages:
                    word_map[token].add((file, page))
    return word_map

def save_word_map_json(word_map):
    structured_map = defaultdict(lambda: defaultdict(set))
    for token, locations in word_map.items():
        for file, page in locations:
            structured_map[token][file].add(page)

    output = {
        token: {
            pdf: sorted(pages)
            for pdf, pages in pdf_map.items()
        }
        for token, pdf_map in structured_map.items()
    }

    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

def load_cache():
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    return {}

def save_cache(cache):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f)

def pdf_check_add(new_pdfs, word_map, cache, folder):
    if new_pdfs:
        print("New PDFs found:", new_pdfs)
        token_maps = []
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(extract_tokens_from_pdf, os.path.join(folder, pdf)) for pdf in new_pdfs]
            for future in as_completed(futures):
                token_maps.append(future.result())
        new_data = merge_token_maps(token_maps)
        for token, locs in new_data.items():
            word_map[token].update(locs)
        for pdf in new_pdfs:
            path = os.path.join(folder, pdf)
            cache[pdf] = {"modified": os.path.getmtime(path)}
    return word_map
            
    
def pdf_check_deleted(deleted_pdfs, word_map, cache):
    if deleted_pdfs:
        print("Deleted PDFs found:", deleted_pdfs)
        for token in list(word_map.keys()):
            updated_locations = {(file, page) for (file, page) in word_map[token] if file not in deleted_pdfs}
            if updated_locations:
                word_map[token] = updated_locations
            else:
                del word_map[token]
        for pdf in deleted_pdfs:
            del cache[pdf]
    return word_map
                


def build_word_map_with_cache(folder):
    all_pdfs = [f for f in os.listdir(folder) if f.lower().endswith(".pdf")]
    all_pdfs_set = set(all_pdfs)
    cache = load_cache()
    cached_pdfs_set = set(cache.keys())

    word_map = defaultdict(set)

    if not os.path.exists(OUTPUT_JSON):
        # No word map yet: full build
        print("word_map.json not found. Building full index...")
        token_maps = []
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(extract_tokens_from_pdf, os.path.join(folder, pdf)) for pdf in all_pdfs]
            for future in as_completed(futures):
                token_maps.append(future.result())
        word_map = merge_token_maps(token_maps)
        # Update cache
        for pdf in all_pdfs:
            path = os.path.join(folder, pdf)
            cache[pdf] = {"modified": os.path.getmtime(path)}
    else:
        # Load existing word map
        word_map = load_existing_word_map_json()
        
        m = len(all_pdfs_set) - len(cached_pdfs_set)

        # Case 1: New PDFs added
        if m > 0:
            word_map = pdf_check_add(all_pdfs_set - cached_pdfs_set, word_map, cache, folder)
        
        # Case 2: PDFs deleted
        elif m < 0:
            word_map = pdf_check_deleted(cached_pdfs_set - all_pdfs_set, word_map, cache)

        # Case 3: Check modified PDFs
        modified_pdfs = set()
        for pdf in all_pdfs:
            path = os.path.join(folder, pdf)
            mod_time = os.path.getmtime(path)
            
            if cache[pdf]["modified"] != mod_time:
                modified_pdfs.add(pdf)
                
        if modified_pdfs:
            word_map = pdf_check_deleted(modified_pdfs, word_map, cache)
            word_map = pdf_check_add(modified_pdfs, word_map, cache, folder)
            
        else:
            print("No PDF files found modified.")
            

    # Save updated map and cache
    save_word_map_json(word_map)
    save_cache(cache)
    return True