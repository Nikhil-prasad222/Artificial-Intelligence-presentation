import os
import re
import threading
import platform
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from ttkbootstrap import Style
from Backend.Dile_Scanner import build_word_map_with_cache
from Backend.Dile_Finder import load_word_map, search_phrase, search_exact_phrase

# === Globals ===
PATH_FILE = "path.txt"
indexing_in_progress = False

# === Helpers ===
def open_pdf(pdf_name, base_folder):
    # First, try directly
    direct_path = os.path.join(base_folder, pdf_name)
    if os.path.exists(direct_path):
        path = direct_path
    else:
        # Search in subfolders
        path = None
        for root, dirs, files in os.walk(base_folder):
            dirs[:] = [d for d in dirs if not d.startswith('.')]  # skip .Database
            if pdf_name in files:
                path = os.path.join(root, pdf_name)
                break

    if not path or not os.path.exists(path):
        messagebox.showerror("Not Found", f"{pdf_name} not found in {base_folder} or subfolders.")
        return

    try:
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        messagebox.showerror("Error", f"Could not open PDF:\n{e}")


def save_path(path):
    with open(PATH_FILE, "w") as f:
        f.write(path)

def load_path():
    return open(PATH_FILE).read().strip() if os.path.exists(PATH_FILE) else ""

def choose_folder():
    selected = filedialog.askdirectory()
    if selected:
        folder_var.set(selected)
        save_path(selected)

def run_indexing():
    global indexing_in_progress
    if indexing_in_progress:
        return

    folder = folder_var.get()
    if not folder or not os.path.isdir(folder):
        messagebox.showwarning("Invalid Folder", "Please select a valid folder.")
        return

    indexing_in_progress = True
    progress.start()
    index_button.config(state=tk.DISABLED)

    scan_subfolders = scan_mode_var.get() == "subfolders"

    def background():
        updated = False
        if scan_subfolders:
            for root, dirs, files in os.walk(folder):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                updated |= build_word_map_with_cache(root)
        else:
            updated = build_word_map_with_cache(folder)

        app.after(0, lambda: on_index_done(updated))

    threading.Thread(target=background, daemon=True).start()

def on_index_done(updated):
    global indexing_in_progress
    indexing_in_progress = False
    progress.stop()
    index_button.config(state=tk.NORMAL)
    msg = "Word map updated." if updated else "No changes detected. Using cached index."
    messagebox.showinfo("Indexing", msg)

def perform_search():
    phrase = search_entry.get().strip()
    result_list.delete(0, tk.END)
    if not phrase:
        return

    search_subfolders = search_mode_var.get() == "subfolders"

    try:
        folders_to_search = []
        if search_subfolders:
            for root, dirs, files in os.walk(folder_var.get()):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                folders_to_search.append(root)
        else:
            folders_to_search = [folder_var.get()]

        matches = []
        for folder in folders_to_search:
            word_map = load_word_map(folder)
            if exact_search_var.get():
                local_matches = search_exact_phrase(phrase, folder)
            else:
                local_matches = search_phrase(word_map, phrase, folder)
            matches.extend(local_matches)

        if matches:
            for m in matches:
                result_list.insert(tk.END, m)
        else:
            result_list.insert(tk.END, "No matches found.")

    except FileNotFoundError:
        messagebox.showerror("Missing File", "Required data files not found. Please create index first.")

def on_pdf_click(event):
    selection = result_list.curselection()
    if not selection:
        return
    item = result_list.get(selection[0])
    match = re.search(r'- (.+\.pdf)$', item) or re.match(r'(.+\.pdf)$', item)
    if match:
        pdf_name = match.group(1).strip()
        open_pdf(pdf_name, folder_var.get())

# === GUI Setup ===
app = tk.Tk()
app.title("PDF Index & Search Tool")
app.geometry("880x640")
app.configure(bg="#f0f4f8")
style = Style("superhero")  # Choose a modern, dark-friendly theme

folder_var = tk.StringVar(value=load_path())
scan_mode_var = tk.StringVar(value="current")
search_mode_var = tk.StringVar(value="current")

container = ttk.Frame(app, padding=15)
container.pack(fill=tk.BOTH, expand=True)

# === Folder Selection ===
folder_frame = ttk.Labelframe(container, text="Folder Selection")
folder_frame.pack(fill=tk.X, pady=10)

folder_entry = ttk.Entry(folder_frame, textvariable=folder_var, width=80, state="readonly")
folder_entry.pack(side=tk.LEFT, padx=5, pady=5)
ttk.Button(folder_frame, text="Browse", command=choose_folder, bootstyle="info").pack(side=tk.LEFT, padx=5)

# === Scan Filter ===
scan_frame = ttk.Labelframe(container, text="Scan Filter")
scan_frame.pack(fill=tk.X, pady=10)

ttk.Radiobutton(scan_frame, text="Current Folder Only", variable=scan_mode_var, value="current").pack(side=tk.LEFT, padx=10, pady=5)
ttk.Radiobutton(scan_frame, text="Include Subfolders", variable=scan_mode_var, value="subfolders").pack(side=tk.LEFT, padx=10, pady=5)

# === Index Button ===
index_button = ttk.Button(container, text="Create Index", command=run_indexing, bootstyle="success")
index_button.pack(pady=10)

progress = ttk.Progressbar(container, mode='indeterminate', length=500)
progress.pack(pady=5)

# === Search Section ===
search_frame = ttk.Labelframe(container, text="Search")
search_frame.pack(fill=tk.X, pady=10)

ttk.Label(search_frame, text="Search Phrase:").pack(anchor="w", padx=10, pady=(5, 0))
search_entry = ttk.Entry(search_frame, width=60)
search_entry.pack(padx=10, pady=5)

exact_search_var = tk.BooleanVar()
ttk.Checkbutton(search_frame, text="Exact Phrase Match", variable=exact_search_var).pack(anchor="w", padx=10)

# === Search Filter ===
search_filter_frame = ttk.Frame(search_frame)
search_filter_frame.pack(anchor="w", padx=10, pady=(5, 0))

ttk.Label(search_filter_frame, text="Search In:").pack(side=tk.LEFT)
ttk.Radiobutton(search_filter_frame, text="Current Folder Only", variable=search_mode_var, value="current").pack(side=tk.LEFT, padx=10)
ttk.Radiobutton(search_filter_frame, text="Include Subfolders", variable=search_mode_var, value="subfolders").pack(side=tk.LEFT, padx=10)

# === Search Button ===
ttk.Button(container, text="Search", command=perform_search, bootstyle="warning").pack(pady=5)

# === Results ===
result_frame = ttk.Labelframe(container, text="Search Results")
result_frame.pack(fill=tk.BOTH, expand=True, pady=10)

result_list = tk.Listbox(result_frame, font=("Consolas", 11), activestyle='dotbox')
result_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
result_list.bind("<Double-1>", on_pdf_click)

scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=result_list.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
result_list.config(yscrollcommand=scrollbar.set)

app.mainloop()
