import os
import re
import json
import fitz  # PyMuPDF
import pytesseract
from collections import defaultdict
from pdf2image import convert_from_path
from concurrent.futures import ProcessPoolExecutor, as_completed

# === CONFIG ===
TESSERACT_PATH = r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
POPPLER_PATH = r"C:\\poppler\\Library\\bin"

pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

# === UTILITY ===
def get_output_paths(folder):
    output_dir = os.path.join(folder, ".Database")
    os.makedirs(output_dir, exist_ok=True)
    return {
        "dir": output_dir,
        "word_map": os.path.join(output_dir, "word_map.json"),
        "page_text": os.path.join(output_dir, "page_text.json"),
        "cache": os.path.join(output_dir, "scan_cache.json")
    }

# === TEXT + TOKEN EXTRACTION ===
def extract_tokens_and_text(pdf_path):
    token_map = defaultdict(set)
    text_map = defaultdict(dict)
    try:
        filename = os.path.basename(pdf_path)
        doc = fitz.open(pdf_path)
        for page_number in range(len(doc)):
            page = doc.load_page(page_number)
            text = page.get_text()

            if not text.strip():
                images = convert_from_path(
                    pdf_path,
                    first_page=page_number + 1,
                    last_page=page_number + 1,
                    poppler_path=POPPLER_PATH
                )
                text = pytesseract.image_to_string(images[0])

            text_map[filename][str(page_number + 1)] = text
            tokens = re.findall(r'\b\w+\b', text)
            for token in tokens:
                token_map[token.lower()].add((filename, page_number + 1))

        return token_map, text_map
    except Exception as e:
        print(f"Error processing {pdf_path}: {e}")
        return defaultdict(set), defaultdict(dict)

# === MERGING ===
def merge_token_maps(all_maps):
    merged = defaultdict(set)
    for token_map in all_maps:
        for token, locations in token_map.items():
            merged[token].update(locations)
    return merged

def merge_text_maps(all_maps):
    merged = defaultdict(dict)
    for text_map in all_maps:
        for file, pages in text_map.items():
            merged[file].update(pages)
    return merged

# === SAVE / LOAD ===
def save_word_map_json(word_map, path):
    structured = defaultdict(lambda: defaultdict(set))
    for token, locs in word_map.items():
        for file, page in locs:
            structured[token][file].add(page)

    output = {
        token: {file: sorted(pages) for file, pages in file_map.items()}
        for token, file_map in structured.items()
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

def save_page_text_json(text_map, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(text_map, f, indent=2)

def load_existing_word_map_json(path):
    word_map = defaultdict(set)
    if not os.path.exists(path):
        return word_map
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        for token, file_pages in data.items():
            for file, pages in file_pages.items():
                for page in pages:
                    word_map[token].add((file, int(page)))
    return word_map

def load_cache(path):
    return json.load(open(path)) if os.path.exists(path) else {}

def save_cache(cache, path):
    with open(path, "w") as f:
        json.dump(cache, f)

# === FILE HANDLING ===
def pdf_check_add(new_pdfs, word_map, cache, folder, text_map):
    token_maps = []
    text_maps = []
    with ProcessPoolExecutor() as executor:
        futures = [executor.submit(extract_tokens_and_text, os.path.join(folder, pdf)) for pdf in new_pdfs]
        for future in as_completed(futures):
            token_data, text_data = future.result()
            token_maps.append(token_data)
            text_maps.append(text_data)

    new_tokens = merge_token_maps(token_maps)
    new_texts = merge_text_maps(text_maps)

    for token, locs in new_tokens.items():
        word_map[token].update(locs)
    for file, pages in new_texts.items():
        text_map[file].update(pages)
    for pdf in new_pdfs:
        path = os.path.join(folder, pdf)
        cache[pdf] = {"modified": os.path.getmtime(path)}
    return word_map, text_map

def pdf_check_deleted(deleted_pdfs, word_map, cache, text_map):
    for token in list(word_map.keys()):
        updated = {(f, p) for (f, p) in word_map[token] if f not in deleted_pdfs}
        if updated:
            word_map[token] = updated
        else:
            del word_map[token]
    for pdf in deleted_pdfs:
        cache.pop(pdf, None)
        text_map.pop(pdf, None)
    return word_map, text_map

# === MAIN FUNCTION ===
def build_word_map_with_cache(folder):
    paths = get_output_paths(folder)
    all_pdfs = [f for f in os.listdir(folder) if f.lower().endswith(".pdf")]
    all_pdfs_set = set(all_pdfs)
    cache = load_cache(paths["cache"])
    cached_set = set(cache.keys())

    word_map = defaultdict(set)
    text_map = defaultdict(dict)

    if not os.path.exists(paths["word_map"]):
        print("Indexing all PDFs...")
        token_maps = []
        text_maps = []
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(extract_tokens_and_text, os.path.join(folder, pdf)) for pdf in all_pdfs]
            for future in as_completed(futures):
                token_data, text_data = future.result()
                token_maps.append(token_data)
                text_maps.append(text_data)
        word_map = merge_token_maps(token_maps)
        text_map = merge_text_maps(text_maps)
        for pdf in all_pdfs:
            cache[pdf] = {"modified": os.path.getmtime(os.path.join(folder, pdf))}
    else:
        word_map = load_existing_word_map_json(paths["word_map"])
        if os.path.exists(paths["page_text"]):
            with open(paths["page_text"], "r", encoding="utf-8") as f:
                text_map = json.load(f)

        deleted = cached_set - all_pdfs_set
        added = all_pdfs_set - cached_set
        modified = {pdf for pdf in all_pdfs if cache.get(pdf, {}).get("modified") != os.path.getmtime(os.path.join(folder, pdf))}

        if deleted:
            print("Removing deleted PDFs from index...")
            word_map, text_map = pdf_check_deleted(deleted, word_map, cache, text_map)
        if added or modified:
            print("Indexing new/modified PDFs...")
            word_map, text_map = pdf_check_add(added | modified, word_map, cache, folder, text_map)
        else:
            print("No updates detected.")

    save_word_map_json(word_map, paths["word_map"])
    save_page_text_json(text_map, paths["page_text"])
    save_cache(cache, paths["cache"])
    return True