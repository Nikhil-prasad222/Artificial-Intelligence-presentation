import os
import json
import re
from collections import defaultdict

# === Helpers ===
def get_word_map_path(folder):
    return os.path.join(folder, ".Database", "word_map.json")

def get_page_text_path(folder):
    return os.path.join(folder, ".Database", "page_text.json")

def load_word_map(folder):
    word_map = defaultdict(set)
    path = get_word_map_path(folder)
    if not os.path.exists(path):
        return word_map
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        for token, file_pages in data.items():
            for file, pages in file_pages.items():
                for page in pages:
                    word_map[token].add((file, int(page)))
    return word_map

def load_page_text(folder):
    path = get_page_text_path(folder)
    if not os.path.exists(path):
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def search_phrase(word_map, phrase, folder):
    tokens = [token.lower() for token in re.findall(r'\b\w+\b', phrase)]
    if not tokens:
        return []
    
    sets = [word_map.get(token, set()) for token in tokens]
    if not all(sets):
        return []

    common_locations = set.intersection(*sets)
    results = []
    for file, page in sorted(common_locations):
        results.append(f"\tPage {page} - {file}")

    if results:
        results = [f"\nTotal PDFs matched: {len(set(f for f, _ in common_locations))}\n"] + results

    return results

def search_exact_phrase(phrase, folder):
    page_text_map = load_page_text(folder)
    results = []
    matched_files = set()
    for file, pages in page_text_map.items():
        for page, text in pages.items():
            if phrase.lower() in text.lower():
                results.append(f"\tPage {page} - {file}")
                matched_files.add(file)

    if results:
        results = [f"\nTotal PDFs matched: {len(matched_files)}\n"] + results

    return results